<?php 
session_start(); 
require_once('class/modelo.php');

class usuariosModelo extends modeloCredencialesDB{

     
    public function __construct()
    {
        parent::_construct();
    }
  

    public function ValidaUsuario($usuario,$Clave) 
    { 
        $usuario = "'".$usuario."'";
        $Clave   = "'".$Clave."'";
        $instruccion = "CALL sp_valida_login(".$usuario.",".$Clave.")";	
        $consulta = $this->_db->query($instruccion);
        $cantiregistros = $consulta->num_rows;
        return  $cantiregistros; 

    }

} 


    $usuarioModel = new usuariosModelo(); 
    $CantidadUsuarios = $usuarioModel->ValidaUsuario( $_POST['Usuario'],$_POST['clave']); 
    if ($CantidadUsuarios > 0)
    {
        $_SESSION["user"] =  $_POST['Usuario']; 
        echo '<script> window.location="dashboard.php"; </script>';
    }
    else 
    {
    header('Location: index.php?errorlogin');
    }

?>
