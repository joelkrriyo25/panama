<!DOCTYPE html>
<html lang="es">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="jquery.min.js"></script> 
<script src="popper.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="angular.min.js"></script> 
<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="css/sb-admin.css" rel="stylesheet">
<script src="angular.min.js"></script> 

  <title> ERROR EN SISTEMA</title>
  
<body>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<div class="container">
  <div class="row">
    <div class="col-sm-12" style = "background-image:url(Img/huevo.png);   background-repeat:no-repeat;  background-position: center; ">
    <center>
      <h1>Ups, Ocurrio un error</h1>
      <p>De persistir el problema</p>
      <p>Contactanos al correo: soporte@parroquiasannicolasdebari.com</p>
      <button class="btn btn-outline-primary"><a  href="http://parroquiasannicolasdebari.com/" >Regresar</a></button>
    </center>
    </div>
  </div>
</div>


</body>
</head>
</html>