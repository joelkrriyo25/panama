<!DOCTYPE html>
<html lang="es">

<head>
<link rel="shortcut icon" href="Img/logo.png">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="jquery.min.js"></script> 
<script src="popper.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="angular.min.js"></script> 
<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="css/sb-admin.css" rel="stylesheet">
<script src="angular.min.js"></script> 
  <script src="//cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
<title> Añadir Nueva Publicación ||  Blog Tec Pty</title>

<body>

<?php 

include 'base.php';

?>
 <div class="container">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Publicaciones</a>
        </li>
        <li class="breadcrumb-item active">Añadir Nueva Publicación </li>
      </ol>


      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-newspaper-o"></i>  Añadir Nueva Publiación</div>
            <div class="card-body">
                <!-- INICIA FORMUlARIO   action = "alamamailalojamiento.php" -->
              <form    method="post" action = "almacenapublicacion.php"  onsubmit="return  validacampos()"  enctype="multipart/form-data">

                   <b><label for="usr">Titulo:</label></b>
                   <input type="text" class="form-control" id="titulo" name = "titulo">
                   <br>
                   <b><label for="usr">Subtitulo:</label></b>
                   <input type="text" class="form-control" id="subtitulo" name = "subtitulo">
                   <br>
                   <b><label for="usr">Contenido:</label></b>
                  <textarea name="editor1" id="editor1" rows="10" cols="80">
                  <div style="background:#eeeeee;border:1px solid #cccccc;padding:5px 10px;"><em><strong>PANAMA EJEMPLO</strong></em></div>

                  <p><em><strong><img alt="" src="https://avatars1.githubusercontent.com/u/29827680?s=88&amp;v=4" style="height:420px; width:420px" /></strong></em></p>

                  <p><strong><em>HOLA </em></strong>=====&gt; como</p>
                  </textarea>

                <input type="text" style=" visibility: hidden;" class="form-control" id="trackingDiv" name="trackingDiv"  type="hidden">
                <b><label>Seleccione una Imagen de Portada:</label></b>
                <div class="custom-file">
                <input type="file" class="custom-file-input" id="archivo" name = "archivo" accept="image/x-png,image/gif,image/jpeg">
                <label class="custom-file-label" for="customFile">Seleccione el Archivo</label>
                </div>
                <hr>
                <button type="submit" style = "background-color:#003087;color:#FFFFFF;" class="btn btn-primary btn-block">Publicar</button>           

              </form>
              
             <!-- TERMINA FORMULARIO FORMUlARIO -->
        <hr>
            </div>
        </div>
               <!--  ************************************* INICIA MODEL  ********************************-->
   <!-- Trigger the modal with a button -->
   <button id="mensajevalidacampos" type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal" style="visibility:hidden;" >
   Open modal
   </button>

  <!-- The Modal -->
  <div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
    
      <!-- Modal Header -->
      <div class="modal-header" style = "background-color: #dc3545;">
        <h4 class="modal-title" style = " color: #EEE8E8;">-Alerta</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
      <!-- Modal body -->
      <div class="modal-body">
             Verificar que todos los campos con un asterisco <span style="color: #ff0000;">(*)</span> esten completos correctamente.
      </div>
      
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Aceptar</button>
      </div>
      
    </div>
  </div>
</div>

<!--  ************************************* FIN  MODEL  ********************************-->
       </div>

</div>



<script type="text/javascript">

// Replace the <textarea id="editor1"> with a CKEditor
// instance, using default configuration.
CKEDITOR.replace( 'editor1' );

function validacampos()
{

var desc = CKEDITOR.instances.editor1.getData();
let lbl = document.getElementById('trackingDiv');
lbl.value = desc;       // TREATS EVERY CONTENT AS TEXT.
var  titulo = document.getElementById("titulo").value;
var  subtitulo = document.getElementById("subtitulo").value;
var  contenido = document.getElementById("trackingDiv").value;
var  imagen = document.getElementById("archivo").value;

if (titulo.length > 0 &&  subtitulo.length > 0 && contenido.length > 0 && imagen.length > 0) 
{
    return true;
}
else 
{
        $('#mensajevalidacampos').click();
        return false; 
}

}

</script>

</body>
</head>
</html>