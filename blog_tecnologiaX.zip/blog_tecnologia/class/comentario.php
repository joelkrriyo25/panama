<?php 

require_once('modelo.php');

class comentario extends modeloCredencialesDB{

    public function __construct()
    {
        parent::_construct();
    }

    public function ingresa_comentario($codigopublicacion,$comentario){
    
        $comentario = "'".$comentario."'";
        $instruccion = "CALL sp_ingresa_comentarios(".$codigopublicacion.",".$comentario.")";
        $consulta = $this->_db->query($instruccion);
        
        if ($consulta <> 1)
        {
            echo "fallo al ingresar opiniones";
        }
        else 
        {
            $this->_db->close();
        }
    }

    public function lista_comentarios($codigopublicacion)
    {

        
        $instruccion = "CALL sp_lista_comentarios(".$codigopublicacion.")";
        $consulta = $this->_db->query($instruccion);
        $resultado =$consulta->fetch_all(MYSQLI_ASSOC);

        if(!$resultado)
        {
            echo "";
        }
        else 
        {
            return $resultado;
            $resultado->close();
            $this->_db->close();
        }

    }


}

?>