-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-12-2018 a las 15:08:26
-- Versión del servidor: 10.1.30-MariaDB
-- Versión de PHP: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `blog_tec_pty`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualiza_publicacion` (IN `PCodigoPublicacion` INT, IN `PTitulo` VARCHAR(250), IN `PSubtitulo` VARCHAR(250), IN `PContenido` TEXT, IN `PimgTitulo` VARCHAR(250))  begin 

	update publicaciones 
    set titulo      = PTitulo, 
        subtitulo   = PSubtitulo,
	    Contenido   = PContenido,
		img_titulo  = PimgTitulo
	 where codigo_post = PCodigoPublicacion;

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_elimina_publicacion` (IN `PcodigoPublicacion` INT)  begin 


Update publicaciones 
set estado =  0
where codigo_post = PcodigoPublicacion;
 

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingresa_comentarios` (IN `PCodigoPublicacion` INT, IN `PComentario` TEXT)  begin

insert into comentarios(codigo_publicacion,Comentario)
values(PCodigoPublicacion,PComentario);

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_inserta_publicacion` (IN `Ptitulo` VARCHAR(250), IN `Psubtitulo` VARCHAR(250), IN `PContenido` TEXT, IN `img_titulo` VARCHAR(250), IN `codigo_usuario` INT)  begin 


	insert into publicaciones(titulo,subtitulo,Contenido,img_titulo,codigo_usuario)
    values(Ptitulo,Psubtitulo,PContenido,img_titulo,codigo_usuario);


end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_blog` ()  begin

SET lc_time_names = 'es_MX';

SELECT codigo_post,
       titulo, 
       subtitulo, 
       img_titulo, 
       codigo_usuario,
       (SELECT Concat(Upper(nombre), " ", Upper(apellido)) 
        FROM   usuario 
        WHERE  codigo_usuario = a.codigo_usuario)  as usuario_publica,
        Date_format(fecha,'%W %d %M %Y') as fecha
FROM   publicaciones a
where  estado =  1; 

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_blog_par` (IN `PCodigo` INT)  begin

SET lc_time_names = 'es_MX';

SELECT codigo_post,
       titulo, 
       subtitulo, 
       img_titulo, 
       codigo_usuario,
       (SELECT Concat(Upper(nombre), " ", Upper(apellido)) 
        FROM   usuario 
        WHERE  codigo_usuario = a.codigo_usuario)  as usuario_publica,
        Date_format(fecha,'%W %d %M %Y') as fecha,
        Contenido
FROM   publicaciones a
WHERE codigo_post = PCodigo;

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_lista_comentarios` (IN `Ppublicacion` INT)  begin 

 SET lc_time_names = 'es_MX';

select  Comentario,DATE_FORMAT(fecha_ingreso, "%d/%M/%Y") as  fecha_ingreso
from comentarios
where codigo_publicacion = Ppublicacion
order by fecha_ingreso desc;


end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_lista_publicaciones` ()  begin 

	  SET lc_time_names = 'es_MX';

      select codigo_post,titulo,(select login from blog_tec_pty.usuario a where a.codigo_usuario = b.codigo_usuario) as Autor ,  DATE_FORMAT(fecha, "%d/%M/%Y") as Fecha
	  from  publicaciones b
where estado = 1;

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ultima_fecha` ()  begin 

SET lc_time_names = 'es_MX';

select concat(DATE_FORMAT(max(fecha), '%W %e %M %Y'),' a las ',DATE_FORMAT(max(fecha),'%r'))  as ulti 
from publicaciones;

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_valida_login` (IN `Pusuario` VARCHAR(255), IN `PClave` VARCHAR(255))  begin 

    Select concat(UPPER(nombre)," ",UPPER(apellido)) as nombre
    from usuario
	where login  = Pusuario
    and   clave = md5(PClave);
    
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `codigo_comentario` int(11) NOT NULL,
  `codigo_publicacion` int(11) NOT NULL,
  `Comentario` text COLLATE utf8_spanish_ci NOT NULL,
  `fecha_ingreso` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`codigo_comentario`, `codigo_publicacion`, `Comentario`, `fecha_ingreso`) VALUES
(1, 1, 'awdawdawdawdawdawd', '2018-12-06 09:29:48'),
(2, 1, 'ejemplo ejempl ejemplo', '2018-12-06 09:46:13'),
(3, 2, 'quiten ese loro jajaja.', '2018-12-06 10:22:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicaciones`
--

CREATE TABLE `publicaciones` (
  `codigo_post` int(11) NOT NULL,
  `titulo` varchar(250) COLLATE utf8_spanish_ci NOT NULL,
  `subtitulo` varchar(250) COLLATE utf8_spanish_ci NOT NULL,
  `Contenido` text COLLATE utf8_spanish_ci NOT NULL,
  `img_titulo` varchar(250) COLLATE utf8_spanish_ci NOT NULL,
  `codigo_usuario` int(11) NOT NULL,
  `estado` int(1) NOT NULL DEFAULT '1',
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `publicaciones`
--

INSERT INTO `publicaciones` (`codigo_post`, `titulo`, `subtitulo`, `Contenido`, `img_titulo`, `codigo_usuario`, `estado`, `fecha`) VALUES
(1, 'Movistar busca ayudar a las marcas a conectar con sus clientes', 'Con el lanzamiento de Movistar Ads la compañía quiere acercar a empresas y clientes con relaciones ganar-ganar.', '<p>aa</p>', 'Jellyfish.jpg', 1, 1, '2018-12-06 14:08:05'),
(2, 'Panama', 'es una tierra', '<div style=\"background:#eeeeee; border:1px solid #cccccc; padding:5px 10px\"><em><strong>PANAMA EJEMPLO</strong></em></div><p><em><strong><img alt=\"\" src=\"https://avatars1.githubusercontent.com/u/29827680?s=88&amp;v=4\" style=\"height:420px; width:420px\" /></strong></em></p><p><strong><em>HOLA </em></strong>=====&gt; como</p>', 'como-ensenar-hablar-loro.jpg', 1, 1, '2018-12-06 13:14:16'),
(3, 'chiriqui', 'la tierra del ganado', '<h2><strong>Chiriqu&iacute; es una provincia al oeste de Panam&aacute; que limita con Costa Rica y el oc&eacute;ano Pac&iacute;fico.</strong></h2>', 'diagrama.png', 1, 1, '2018-12-06 13:14:16'),
(4, 'Panama', 'es una tierra', '<div style=\"background:#eeeeee; border:1px solid #cccccc; padding:5px 10px\"><em><strong>PANAMA EJEMPLO</strong></em></div><p><em><strong><img alt=\"\" src=\"https://avatars1.githubusercontent.com/u/29827680?s=88&amp;v=4\" style=\"height:420px; width:420px\" /></strong></em></p><p><strong><em>HOLA </em></strong>=====&gt; como</p>', '', 1, 1, '2018-12-06 13:53:07'),
(5, 'rrrrrrrrrrrrrrrrrrrrrrr', 'Con el lanzamiento de Movistar Ads la compañía quiere acercar a empresas y clientes con relaciones ganar-ganar.', '<p>dawdawdawdaw</p>', '', 1, 0, '2018-12-06 14:00:38'),
(6, 'aaaaaa', 'Con el lanzamiento de Movistar Ads la compañía quiere acercar a empresas y clientes con relaciones ganar-ganar.', '<p>dawdawdawdaw</p>', '', 1, 1, '2018-12-06 13:53:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `codigo_usuario` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `apellido` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `img` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `login` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `clave` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1',
  `tipo` int(11) NOT NULL DEFAULT '1',
  `creado_en` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`codigo_usuario`, `nombre`, `apellido`, `img`, `email`, `login`, `clave`, `estado`, `tipo`, `creado_en`) VALUES
(1, 'Joel', 'Carrillo', '', 'joelcrrll06@gmail.com', 'joelkrriyo25', '67d220c99be3936080280ee0d8f0bf32', 1, 1, '2018-11-21 02:12:49');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `publicaciones`
--
ALTER TABLE `publicaciones`
  ADD PRIMARY KEY (`codigo_post`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`codigo_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `publicaciones`
--
ALTER TABLE `publicaciones`
  MODIFY `codigo_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `codigo_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
