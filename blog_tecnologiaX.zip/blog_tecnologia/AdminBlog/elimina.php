<?php 

require_once('class/publicacion.php');

$publicacion = new publicacion();
$codigoencuestado = $publicacion->elimina_publicacion($_GET['publi']);


header('Location: edit.php');           

                                            
?>