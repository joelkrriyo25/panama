<?php 

require_once('modelo.php');

class publicacion extends modeloCredencialesDB{

    protected $titulo;
    protected $subtitulo;
    protected $Contenido;
    protected $img_titulo;
    protected $codigo_usuario;

    public function __construct()
    {
        parent::_construct();
    }

    public function ingresa_publiacion($titulo,$subtitulo,$Contenido,$img_titulo,$codigo_usuario){
        
        $titulo = "'".$titulo."'";
        $subtitulo = "'".$subtitulo."'";
        $Contenido = "'".$Contenido."'";
        $img_titulo = "'".$img_titulo."'";
        $codigo_usuario = "'".$codigo_usuario."'";
        $instruccion = "CALL sp_inserta_publicacion(". $titulo.",".$subtitulo.",".$Contenido.",".$img_titulo.",".$codigo_usuario.")";
        $consulta = $this->_db->query($instruccion);
        
        
        if ($consulta <> 1)
        {
            echo "fallo al ingresar opiniones";
        }
        else 
        {
            $this->_db->close();
        }

    }

    public function actualiza_publicacion($codigo_publi,$titulo,$subtitulo,$Contenido,$img_titulo)
    {
        $titulo = "'".$titulo."'";
        $subtitulo = "'".$subtitulo."'";
        $Contenido = "'".$Contenido."'";
        $img_titulo = "'".$img_titulo."'";
        $instruccion = "CALL sp_actualiza_publicacion(".$codigo_publi.",".$titulo.",".$subtitulo.",".$Contenido.",".$img_titulo.")";
        $consulta = $this->_db->query($instruccion);
        
        if ($consulta <> 1)
        {
            echo "fallo al actualizar publicacion";
        }
        else 
        {
            $this->_db->close();
        }

    }

    public function elimina_publicacion($codigo_publi)
    {

        $instruccion = "CALL sp_elimina_publicacion(".$codigo_publi.")";
        $consulta = $this->_db->query($instruccion);
        
        if ($consulta <> 1)
        {
            echo "fallo al eliminar";
        }
        else 
        {
            $this->_db->close();
        }
        
    }

    public function lista_publicaciones()
    {
 
     $instruccion = "CALL sp_lista_publicaciones()";
     $consulta = $this->_db->query($instruccion);
     $resultado = $consulta->fetch_all(MYSQLI_ASSOC);
 
     if(!$resultado)
     {
         echo "fallo al consultar las publicaciones.";
     }
     else 
     {
         return $resultado;
         $resultado->close();
         $this->_db->close();
     }
 
    }
 
    public function lista_max_fecha()
    {
 
     $instruccion = "CALL sp_ultima_fecha()";
     $consulta = $this->_db->query($instruccion);
     $resultado = $consulta->fetch_all(MYSQLI_ASSOC);
 
     if(!$resultado)
     {
         echo "fallo al consultar maxima fecha.";
     }
     else 
     {
         return $resultado;
         $resultado->close();
         $this->_db->close();
     }
 
    }


}

?>