<?php 

require_once('modelo.php');

class blog extends modeloCredencialesDB{
    protected $codigo_blog;
    protected $titulo;
    protected $subtitulo;
    protected $img_titulo; 
    protected $codigo_usuario; 
    protected $fecha;

    public function __construct()
    {
        parent::_construct();
    }

    public function consultar_post_blog(){
    
        $instruccion = "CALL sp_listar_blog()";
        $consulta = $this->_db->query($instruccion);
        $resultado =$consulta->fetch_all(MYSQLI_ASSOC);

        if(!$resultado)
        {
            echo "fallo al consultar los post del blog.";
        }
        else 
        {
            return $resultado;
            $resultado->close();
            $this->_db->close();
        }

    }

    public function consultar_info_noticia($codigpost)
    {

        $instruccion = "CALL sp_listar_blog_par(".$codigpost.")";
        $consulta = $this->_db->query($instruccion);
        $resultado =$consulta->fetch_all(MYSQLI_ASSOC);

        if(!$resultado)
        {
            echo "fallo al consultar los post del blog.";
        }
        else 
        {
            return $resultado;
            $resultado->close();
            $this->_db->close();
        }

    }

    
/*
    public function consultar_noticias_filtro($campo,$valor){
        $instruccion = "CALL sp_listar_noticias_filtro('".$campo."','".$valor."')";

        $consulta = $this->_db->query($instruccion);
        $resultado = $consulta->fetch_all(MYSQLI_ASSOC);

        if(!$resultado)
        {
            echo "fallo al consultar las noticias";
        }
        else 
        {
            return $resultado;
            $resultado->close();
            $this->_db->close();
        }
    }

    public function consultar_noticias(){
    
        $instruccion = "CALL sp_listar_noticias()";

        $consulta = $this->_db->query($instruccion);
        $resultado =$consulta->fetch_all(MYSQLI_ASSOC);

        if(!$resultado)
        {
            echo "fallo al consultar las noticias";
        }
        else 
        {
            return $resultado;
            $resultado->close();
            $this->_db->close();
        }

    }
*/

}

?>