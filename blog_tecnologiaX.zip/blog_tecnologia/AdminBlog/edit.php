<!DOCTYPE html>
<html lang="es">

<head>
<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
<title> Todas las Publicaciones ||  Blog Tec Pty</title>

<body>

<?php 

include 'base.php';

?>
 <div class="container">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Publicaciones</a>
        </li>
        <li class="breadcrumb-item active">Todas las Publicaciones</li>
      </ol>


      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Publicaciones</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  
                  <th>ID</th>
                  <th>Titulo</th>
                  <th>Autor</th>
                  <th>Fecha de Publicación</th>
                 
                </tr>
              </thead>
              <tfoot>
                <tr>
                
                <th>ID</th>
                  <th>Titulo</th>
                  <th>Autor</th>
                  <th>Fecha de Publicación</th>
                
                </tr>
              </tfoot>
              <tbody>
                
              <?php 	

                require_once('class/publicacion.php');

                $obj_publicacion = new publicacion();
                $publicaciones = $obj_publicacion->lista_publicaciones();
                $nfilas = count($publicaciones);

                foreach($publicaciones as $resultado)
                {
                  
                  $valor = $resultado['codigo_post'];

                  echo'<tr>
                                
                  <td> <a href="modify.php?regis='.$valor.'">'.$valor.'</a></td>
                  <td>'.$resultado['titulo'].'</td>
                  <td>'.$resultado['Autor'].'</td>
                  <td>'.$resultado['Fecha'].'</td>
                  </tr>'; 

                }                   
                            
						?>

              </tbody>
            </table>
          </div>
        </div>

        <div class="card-footer small text-muted"><b>Última Actualización</b> 
                              <?php 
                              $obj_publicacion = new publicacion();
                              $maxfecha = $obj_publicacion->lista_max_fecha();
                              
                                foreach($maxfecha as $resultado)
                                {
                                  
                                  echo  $resultado['ulti'];
                                }   
                              //$nfilas = count($publicaciones);
                               
                               

                               ?>
                               </div>

      </div>

    </div>
</div>
</div>
</div>
</div>

<script type="text/javascript">

    $('#dataTable').DataTable( {
        "language": {"sProcessing":     "Procesando...",
            "sLengthMenu":     "Mostrar _MENU_ registros",
            "sZeroRecords":    "No se encontraron resultados",
            "sEmptyTable":     "Ningún dato disponible en esta tabla",
            "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix":    "",
            "sSearch":         "Buscar:",
            "sUrl":            "",
            "sInfoThousands":  ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst":    "Primero",
                "sLast":     "Último",
                "sNext":     "Siguiente",
                "sPrevious": "Anterior"
            },
            "oAria": {
                "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
            }
        }
    } );


</script>

</body>
</head>
</html>