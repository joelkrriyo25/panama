<?php 

require_once('class/publicacion.php');

$publicacion = new publicacion();
$codigoencuestado = $publicacion->ingresa_publiacion(
                                                        $_POST['titulo'],
                                                        $_POST['subtitulo'],
                                                        $_POST['trackingDiv'],
                                                        $_FILES['archivo']['name'],
                                                        1
                                                    );

if (is_uploaded_file ($_FILES['archivo']['tmp_name'] ))
{
$nombreDirectorio = "img/";
$nombrearchivo = $_FILES['archivo']['name'];
$nombreCompleto = $nombreDirectorio . $nombrearchivo;

if (is_file($nombreCompleto))
{

$idUnico = time();
$nombrearchivo = $idUnico . "-" . $nombrearchivo;
echo "Archivo repetido, se cambiara el nombre a $nombrearchivo
<br><br>";

}

move_uploaded_file ($_FILES['archivo']['tmp_name'], $nombreDirectorio . $nombrearchivo);

echo "El archivo se ha subido satisfactoriamente al directorio
$nombreDirectorio <br>";

}

else
echo "No se ha podido subir el archivo <br>";


header('Location: edit.php');    
                                            
?>