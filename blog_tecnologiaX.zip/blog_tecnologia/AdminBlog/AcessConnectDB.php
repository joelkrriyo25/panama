<?php

class Modelo 
{ 
    protected $_db; 

    public function __construct() 
    { 
       
        $this->_db = mysql_connect('Localhost', 'parroqui_joel', 'Panama2016');
	     mysql_select_db('parroqui_sysjmjdb');
         mysql_query ("SET NAMES 'utf8'");
 
    } 


}

?>