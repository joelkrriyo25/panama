<?php 

require_once('class/comentario.php');

$comentario = new comentario();
$codigocomentario = $comentario->ingresa_comentario($_POST['codigo'],$_POST['comment']);


header('Location: post.php?publi='.$_POST['codigo']);    
                                            
?>